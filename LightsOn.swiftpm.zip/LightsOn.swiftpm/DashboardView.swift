//
//  DashboardView.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/10/25.
//

import SwiftUI

struct DashboardView: View {
    
    // Sidebar
    @State private var restart = false
    @State private var showRestartMessage = false
    
    @State private var openedApp = ""
    @State private var hasCompletedStory = false
    @State private var hasTappedOnIntroMessage = false
    @State private var finishStory = false
    
    @State private var usedRefineBefore = false
    
    // Hand Tracking
    @State private var overlayPoints: [CGPoint] = []
    let closeApp = NotificationCenter.default.publisher(for: NSNotification.Name("close"))
    
    @State private var showingPortraitAlert = false
    @State private var bgColor = Color(red: 0.04, green: 0.15, blue: 0.25)

    
    var body: some View {
        ZStack {
            if openedApp == "refine" {
                CameraView {
                    overlayPoints = $0
                }
                .opacity(0.1)
                .frame(width: 1000, height: 500)
            }

            bgColor
                .ignoresSafeArea()
            HStack {
                Spacer()
                ZStack {
                    Rectangle()
                        .border(Color(red: 0.48, green: 1.00, blue: 1.00), width: 4)
                        .foregroundStyle(Color(red: 0.04, green: 0.15, blue: 0.25).opacity(0.7))
                        .frame(width: 200, height: 500)
                    
                    // Sidebar Contents
                    
                    VStack {
                        // Communication
                        Button {
                            withAnimation {
                                openedApp = "messages"
                            }
                        } label: {
                            HStack {
                                Image(systemName: "message.fill")
                                    .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                    .font(.title2)
                                    .padding(.leading)
                                    .frame(width: 40)
                                
                                Text("Messages")
                                    .font(.title2)
                                    .padding(.leading, 10)
                                    .fontWeight(.semibold)
                                    .monospaced()
                                    
                                
                                Spacer()
                            }
                            .frame(width: 176, height: 55)
                            .background {
                                Rectangle()
                                    .foregroundStyle(.white.opacity(0.1))
                            }
                        }
                        .buttonStyle(.plain)
                        .padding(.top, 12)
                        
                        // Power
                        Button {
                            withAnimation {
                                openedApp = "power"
                            }
                        } label: {
                            HStack {
                                Image(systemName: "bolt.fill")
                                    .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                    .font(.title2)
                                    .padding(.leading)
                                    .frame(width: 40)
                                    
                                Text("Power")
                                    .font(.title2)
                                    .padding(.leading, 10)
                                    .fontWeight(.semibold)
                                    .monospaced()
                                
                                Spacer()
                                
                            }
                            .frame(width: 176, height: 55)
                            .background {
                                Rectangle()
                                    .foregroundStyle(.white.opacity(0.1))
                            }
                        }
                        .buttonStyle(.plain)
                        
                        // Refine
                        Button {
                            withAnimation {
                                openedApp = "refine"
                            }
                        } label: {
                            HStack {
                                Image(systemName: "numbers")
                                    .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                    .font(.title3)
                                    .padding(.leading)
                                    .frame(width: 40)
                                    .bold()
                                Text("Refine")
                                    .font(.title2)
                                    .padding(.leading, 10)
                                    .fontWeight(.semibold)
                                    .monospaced()
                                
                                Spacer()
                                
                            }
                            .frame(width: 176, height: 55)
                            .background {
                                Rectangle()
                                    .foregroundStyle(.white.opacity(0.1))
                            }
                        }
                        .buttonStyle(.plain)
                        
                        
                        // Icon Studio
                        Button {
                            withAnimation {
                                openedApp = "mapping"
                            }
                        } label: {
                            HStack {
                                Image(systemName: "map.fill")
                                    .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                    .font(.title2)
                                    .padding(.leading)
                                    .frame(width: 40)
                                
                                Text("Mapping")
                                    .font(.title2)
                                    .padding(.leading, 10)
                                    .fontWeight(.semibold)
                                    .monospaced()
                                Spacer()
                                
                            }
                            .frame(width: 176, height: 55)
                            .background {
                                Rectangle()
                                    .foregroundStyle(.white.opacity(0.1))
                            }
                        }
                        .buttonStyle(.plain)
                        
                        // Countdown
                        Button {
                            withAnimation {
                                openedApp = "countdown"
                            }
                        } label: {
                            HStack {
                                Image(systemName: "calendar")
                                    .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                    .font(.title2)
                                    .padding(.leading)
                                    .frame(width: 40)
                                
                                Text("Countdown")
                                    .font(.system(size: 19))
                                    .padding(.leading, 10)
                                    .fontWeight(.semibold)
                                    .monospaced()
                                    
                                Spacer()
                                
                            }
                            .frame(width: 176, height: 55)
                            .background {
                                Rectangle()
                                    .foregroundStyle(.white.opacity(0.1))
                            }
                        }
                        .buttonStyle(.plain)
                        
                        Spacer()
                        
                        // Controls
                        HStack {
                            // About
                            Button {
                                withAnimation {
                                    openedApp = "info"
                                }
                            } label: {
                                HStack {
                                    Image(systemName: "info")
                                        .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                        .font(.title)
                                }
                                .frame(height: 55)
                                .frame(maxWidth: .infinity)
                                .background {
                                    Rectangle()
                                        .foregroundStyle(.white.opacity(0.1))
                                    
                                }
                            }
                            .buttonStyle(.plain)
                            
                            Spacer()
                            // Restart
                            Button {
                                showRestartMessage = true
                            } label: {
                                HStack {
                                    Image(systemName: "arrow.clockwise")
                                        .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                        .font(.title)
                                    
                                }
                                .frame(height: 55)
                                .frame(maxWidth: .infinity)
                                .background {
                                    Rectangle()
                                        .foregroundStyle(.white.opacity(0.1))
                                }
                            }
                            .buttonStyle(.plain)
                            .alert("Restart LightsOn?", isPresented: $showRestartMessage) {
                                Button("Cancel", role: .cancel) { }
                                Button("Restart", role: .destructive) {
                                    restart = true
                                    personName = "Deputy Manager"
                                }
                            } message: {
                                Text("Any progress will be lost. Are you sure you want to restart?")
                            }
                        }
                        .frame(width: 176, height: 55)
                        .padding(.horizontal)
                        
                        
                        // Settings
                        Button {
                            withAnimation {
                                openedApp = "settings"
                            }
                        } label: {
                            HStack {
                                Image(systemName: "gear")
                                    .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                                    .font(.title2)
                                    .padding(.leading)
                                    .frame(width: 40)
                                
                                Text("Settings")
                                    .font(.title2)
                                    .padding(.leading, 10)
                                    .fontWeight(.semibold)
                                    .monospaced()
                                Spacer()
                                
                            }
                            .frame(width: 176, height: 55)
                            .background {
                                Rectangle()
                                    .foregroundStyle(.white.opacity(0.1))
                            }
                        }
                        .buttonStyle(.plain)
                        .padding(.bottom, 12)
                    }
                    .frame(width: 200, height: 500)      
                    .navigationDestination(isPresented: $restart) {
                        ContentView()
                            .navigationTitle("")
                            .navigationBarBackButtonHidden(true)
                            .navigationBarHidden(true)
                    }
                }
                .padding(.trailing)

                ZStack {
                    Color.clear
                        .frame(width: 800, height: 500)

                    Rectangle()
                        .border(Color(red: 0.48, green: 1.00, blue: 1.00), width: 4)
                        .foregroundStyle(Color(red: 0.04, green: 0.15, blue: 0.25).opacity(0.7))
                        .frame(width: 800, height: 500)
                    
                    
                    switch openedApp {
                    case "messages":
                        MessagesApp(hasCompletedStory: $hasCompletedStory, currentApp: $openedApp, tappedOnIntroMessage: $hasTappedOnIntroMessage, finishStory: $finishStory)
                    case "power":
                        PowerApp(hasCompletedStory: $hasCompletedStory, currentApp: $openedApp, finishStory: $finishStory, bgColor: $bgColor)
                    case "refine":
                        if hasCompletedStory {
                            RefineApp(overlayPoints: $overlayPoints, usedRefineBefore: $usedRefineBefore)
                        } else {
                            PowerFailureMessageView()
                        }
                    case "mapping":
                        if hasCompletedStory {
                            MappingApp()
                        } else {
                            PowerFailureMessageView()
                        }
                    case "countdown":
                        if hasCompletedStory {
                            CountdownApp()
                        } else {
                            PowerFailureMessageView()
                        }
                    case "info":
                        InfoApp()
                    case "settings":
                        SettingsApp()
                    case "" :
                        DefaultDashboardView(currentApp: $openedApp, hasCompletedStory: $hasCompletedStory, bgColor: $bgColor, tappedOnIntroMessage: $hasTappedOnIntroMessage)
                    default:
                        DefaultDashboardView(currentApp: $openedApp, hasCompletedStory: $hasCompletedStory, bgColor: $bgColor, tappedOnIntroMessage: $hasTappedOnIntroMessage)                    }
                }
                .frame(width: 800, height: 500)
                .onReceive(closeApp) {_ in
                    withAnimation(.easeOut(duration: 0.5)) {
                        openedApp = ""
                    }
                }
                Spacer()
            }
            .padding()
        }
        .overlay {
            if showingPortraitAlert {
                VStack {
                    Image(systemName: "rectangle.landscape.rotate")
                        .font(.system(size: 80))
                        .padding()
                    Text("Rotate Device to Landscape")
                        .font(.title)
                }
                .bold()
                .frame(width: 300, height: 300, alignment: .center)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                .shadow(radius: 15)
                .onTapGesture {
                    showingPortraitAlert = false
                }
            }
        }
        .onAppear {
            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
            withAnimation {
                self.showingPortraitAlert = scene.interfaceOrientation.isPortrait
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
            withAnimation {
                self.showingPortraitAlert = scene.interfaceOrientation.isPortrait
            }
        }
    }
}

#Preview {
    DashboardView()
}
