//
//  DefaultDashboardView.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/13/25.
//

import SwiftUI

struct DefaultDashboardView: View {
    
    @Binding var currentApp: String
    @Binding var hasCompletedStory: Bool
    @Binding var bgColor: Color
    @Binding var tappedOnIntroMessage: Bool
    
    @State private var showIntroMessage = false
    
    var body: some View {
        VStack {
            HStack {
                Text("Hello \(personName).")
                Spacer()
                Text("Dashboard")
            }
            .font(.title)
            .bold()
            .monospaced()
            
            Divider()
                .overlay(.white)
            
            VStack {
                Text("Messages")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .monospaced()
                
                Spacer()
                if showIntroMessage {
                    Button {
                        currentApp = "messages"
                        tappedOnIntroMessage = true
                    } label: {
                        HStack {
                            VStack(spacing: 5) {
                                Image(systemName: "message.fill")
                                Text("Manager")
                                    .fontWeight(.semibold)
                            }
                            .font(.title2)
                            .padding()
                            
                            Spacer()
                            
                            VStack {
                                Text("\(personName), I need your help ASAP. There has been a power failure in the office. Please respond and fix this immediately.")
                                    .multilineTextAlignment(.center)
                                
                                Text("Tap on the message to begin the story.")
                                    .foregroundStyle(.secondary)
                                    .font(.footnote)
                            }
                            Spacer()
                        }
                        .border(Color.white, width: 1)
                        .padding()
                    }
                    .buttonStyle(.plain)
                } else {
                    Text("No Active Messages")
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
            }
            .frame(height: 160)
            
            Divider()
                .overlay(.white)
            
            HStack(spacing: 0) {
                VStack {
                    Text("Power Overview")
                        .fontWeight(.semibold)
                        .font(.title2)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .monospaced()
                    
                    Spacer()
                    Group {
                        if showIntroMessage {
                            PowerView(name: "Main", subtext: "Main Power | FAILURE", color: .red)
                            PowerView(name: "MDR", subtext: "MDR Terminal Power | FAILURE", color: .red)
                            PowerView(name: "Break Room", subtext: "Employee Break Room Power | FAILURE", color: .red)
                        } else {
                            PowerView(name: "Main", subtext: "Main Power | FUNCTIONAL", color: .green)
                            PowerView(name: "MDR", subtext: "MDR Terminal Power | FUNCTIONAL", color: .green)
                            PowerView(name: "Break Room", subtext: "Employee Break Room Power | FUNCTIONAL", color: .green)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 5)
                    Spacer()
                }
                Divider()
                
                VStack {
                    
                    Text("Active Alerts")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.leading)
                        .monospaced()
                    
                    Spacer()
                    
                    if showIntroMessage {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundStyle(.yellow)
                            .font(.largeTitle)
                            .padding()
                        
                        Text("3 Active Alerts")
                            .font(.title)
                            .fontWeight(.medium)
                    } else {
                        Text("No Active Alerts")
                            .foregroundStyle(.secondary)
                    }
                    
                    Spacer()
                }
            }
            Spacer()
        }
        .padding()
        .onAppear {
            if !hasCompletedStory {
                if !tappedOnIntroMessage {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation {
                            bgColor = .black
                        }
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        withAnimation {
                            showIntroMessage = true
                        }
                    }
                } else {
                    bgColor = .black
                    showIntroMessage = true
                }
            }
        }
    }
}

#Preview {
    DefaultDashboardView(currentApp: .constant(""), hasCompletedStory: .constant(false), bgColor: .constant(.black), tappedOnIntroMessage: .constant(false))
}

struct PowerView: View {
    @State var name: String
    @State var subtext: String
    @State var color: Color
    
    var body : some View {
        HStack {
            Circle()
                .fill(color)
                .frame(height: 35)
                .padding(.trailing, 5)
            
            VStack(alignment: .leading) {
                Text(name)
                    .font(.title3)
                    .fontWeight(.medium)
                
                Text(subtext)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    
            }
        }
    }
}
