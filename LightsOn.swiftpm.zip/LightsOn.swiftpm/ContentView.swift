var personName = "Deputy Manager"

import SwiftUI
import AVFoundation

struct ContentView: View {
    // First view
    
    // Background
    let bgColors = [Color(red: 0.64, green: 0.29, blue: 0.66), Color(red: 0.26, green: 0.59, blue: 0.42), Color(red: 0.28, green: 0.62, blue: 0.96)]
    @State private var bgAnimate = false
    
    // Button
    @State private var buttonMax = false
    @State private var initialName = ""
    @FocusState private var textFieldFocus: Bool
    @State private var cameraGranted = false
    
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: bgColors), startPoint: bgAnimate ? .topLeading : .bottomLeading, endPoint: bgAnimate ? .bottomTrailing : .topTrailing)
                .ignoresSafeArea(.all)
                .onAppear {
                    withAnimation(.linear(duration: 10.0).repeatForever(autoreverses: true)) {
                        bgAnimate.toggle()
                    }
                }
                .blur(radius: 50)
                .scaleEffect(1.5)
                .opacity(0.5)
            
            VStack {
                VStack {
                    // Title & Subtitle Text
                    Group {
                        Image(systemName: "lightswitch.on")
                            .font(.system(size: 40, weight: .heavy))
                        
                        Text("LightsOn")
                            .font(.system(size: 50, weight: .semibold))
                            .padding(.bottom, 1)
                            .monospaced()
                        
                        Text("The work is mysterious and important.")
                            .multilineTextAlignment(.center)
                            .font(.system(size: 25, weight: .semibold))
                            .padding(.vertical)
                    }
                    .blur(radius: textFieldFocus ? 20 : 0)
                    // Name Text Field
                    ZStack {
                        Color.white.opacity(0.75)
                        HStack {
                            ZStack(alignment: .leading) {
                                if initialName.isEmpty {
                                    Text("Enter your name (Optional)")
                                        .foregroundColor(.gray)
                                        .padding()
                                }
                                TextField("", text: $initialName)
                                    .padding()
                                    .focused($textFieldFocus)
                                    .onChange(of: initialName) {
                                        DispatchQueue.main.async {
                                            personName = initialName
                                        }
                                    }
                            }
                            Spacer()
                            Button("Done") {
                                textFieldFocus = false
                            }
                            .padding(.trailing)
                        }
                    }
                    .foregroundColor(.black)
                    .frame(maxWidth: 450, maxHeight: 30)
                    .padding()
                }
                .padding()
                .frame(maxWidth: 500)
                .background(.white.opacity(0.12))
                
                // Camera Access View
                HStack {
                    Group {
                        Image(systemName: "camera")
                            .font(.system(size: 40, weight: .medium))
                            .frame(width: 60)
                        VStack(alignment: .leading) {
                            Text("Camera Access")
                                .font(.system(size: 25, weight: .semibold))
                            Text("Hand Tracking")
                                .font(.system(size: 18))
                                .foregroundStyle(.secondary)
                            
                            if !cameraGranted {
                                Button {
                                    UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
                                } label: {
                                    Text("Enable camera access in settings to use hand tracking.")
                                        .foregroundStyle(.secondary)
                                        .font(.footnote)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        
                        Spacer()
                        Text(cameraGranted ? "Granted" : "Not Granted")
                            .fontWeight(.bold)
                            .foregroundStyle(cameraGranted ? .green : .red)
                    }
                    .blur(radius: textFieldFocus ? 20 : 0)
                }
                .padding()
                .frame(maxWidth: 500)
                .background(.white.opacity(0.12))
                
                // Apple Pencil Integration View
                HStack {
                    Group {
                        Image(systemName: "applepencil")
                            .font(.system(size: 40, weight: .medium))
                            .frame(width: 60, alignment: .center)
                        Text("Apple Pencil")
                            .font(.system(size: 25, weight: .semibold))
                        Spacer()
                        Text("Supported")
                            .fontWeight(.bold)
                            .foregroundStyle(.secondary)
                    }
                    .blur(radius: textFieldFocus ? 20 : 0)
                }
                .padding()
                .frame(maxWidth: 500)
                .background(.white.opacity(0.12))
                
                NavigationLink {
                    DashboardView()
                        .navigationTitle("")
                        .navigationBarBackButtonHidden(true)
                        .navigationBarHidden(true)
                } label: {
                    ZStack {
                        Circle()
                            .strokeBorder(LinearGradient(gradient: Gradient(colors: bgColors), startPoint: .bottomLeading, endPoint: .topTrailing), lineWidth: 18)
                            .scaleEffect(buttonMax ? 0.95 : 1.1)
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 5).repeatForever(autoreverses: true), {
                                    buttonMax = true
                                })
                            }
                        VStack {
                            Text("Start")
                            Image(systemName: "arrow.right")
                        }
                        .font(.system(size: 40, weight: .semibold))
                        .foregroundColor(.white)
                        .monospaced()
                    }
                    .ignoresSafeArea(.keyboard)
                    .frame(maxWidth: 240, maxHeight: 190)
                }
                .padding(.top, 30)
            }
        }
        .onAppear {
            AVCaptureDevice.requestAccess(for: .video) { cameraAccessStatus in
                cameraGranted = cameraAccessStatus
            }
        }
    }
}
