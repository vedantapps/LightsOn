//
//  Canvas.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/17/25.
//

import SwiftUI
import PencilKit

struct Canvas: UIViewRepresentable {
    @Binding var canvas: PKCanvasView
    @Binding var tools: PKToolPicker
    @Binding var toolVisible: Bool
    
    func makeUIView(context: Context) -> PKCanvasView {
        canvas.drawingPolicy = .anyInput
        return canvas
    }

    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        DispatchQueue.main.async {
            tools.addObserver(uiView)
            tools.setVisible(toolVisible, forFirstResponder: uiView)
            if toolVisible {
                uiView.becomeFirstResponder()
            }
        }
    }
}

