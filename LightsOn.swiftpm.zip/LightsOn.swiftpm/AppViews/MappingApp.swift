//
//  MappingApp.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/14/25.
//

import SwiftUI
import PencilKit

struct MappingApp: View {
    
    @State private var canvasView = PKCanvasView()
    @State private var tools = PKToolPicker()
    
    var body: some View {
        VStack {
            HStack {
                Text("Mapping")
                    .font(.title)
                    .fontWeight(.semibold)
                    .monospaced()
                
                Spacer()
                
                HStack {
                    Image(systemName: "applepencil")
                    Text("Supported")
                }
                .font(.title)
                .foregroundStyle(.secondary)
                .padding(.horizontal)
                .overlay {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .stroke(.secondary, lineWidth: 1)
                }
                .padding(.trailing)
                
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "x.circle.fill")
                        .foregroundStyle(.white)
                        .font(.title)
                }
            }
            Divider()
                .overlay(.white)
            
            Spacer()
            
            HStack {
                Canvas(canvas: $canvasView, tools: $tools, toolVisible: .constant(true))
                    .frame(width: 400, height: 350)
                    .border(Color(red: 0.48, green: 1.00, blue: 1.00), width: 2)
                    .padding(.leading)
                
                Spacer()
                
                VStack(spacing: 15) {
                    Text("Mapping Tool")
                        .font(.largeTitle)
                        .monospaced()
                        .bold()
                    
                    Text("Draft your company hallways")
                        .font(.title2)
                    
                    Button("Clear", systemImage: "trash") {
                        canvasView.drawing.strokes = []
                    }
                    .buttonStyle(.bordered)
                    .font(.title2)
                    .foregroundStyle(.white)
                }
                Spacer()   
            }
            Spacer()
        }
        .padding()
    }
}

#Preview {
    MappingApp()
}
