//
//  PowerFailureMessageView.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/21/25.
//

import SwiftUI

struct PowerFailureMessageView: View {
    var body: some View {
        VStack {
            Image(systemName: "hand.thumbsdown.fill")
                .font(.system(size: 80))
                .padding()
            
            Text("Power Failure. Please restore power via the Power app first.")
                .font(.title3)
                .multilineTextAlignment(.center)
                .monospaced()
        }
        .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
        .padding(30)
        .border(Color.white, width: 2)
        .frame(maxWidth: 600)
    }
}

#Preview {
    PowerFailureMessageView()
}
