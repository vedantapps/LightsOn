//
//  SettingsApp.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/14/25.
//

import SwiftUI

struct SettingsApp: View {
    
    @State private var confidence = Double(trackingConfidence)
    
    var body: some View {
        VStack {
            HStack {
                Text("Settings")
                    .font(.title)
                    .fontWeight(.semibold)
                    .monospaced()
                
                Spacer()
                
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "x.circle.fill")
                        .foregroundStyle(.white)
                        .font(.title)
                }
            }
            Divider()
                .overlay(.white)
                .padding(.bottom,2)
            
            List {
                Section(header: Text("Hand Tracking Settings (Refine)"), footer: Text("Adjust the slider to increase/decrease hand tracking confidence. Higher may not always be better.")) {
                    HStack {
                        Text("Tracking Confidence")
                        Slider(value: $confidence, in: 0.1...0.9)
                            .padding(.horizontal)
                        Text("\(confidence)")
                    }
                    .onChange(of: confidence) {
                        trackingConfidence = Float(confidence)
                    }
                }
                .listRowBackground(Color.clear)
                .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                
                
                Section {
                    Button("Restore Tracking Defaults") {
                        confidence = 0.20
                    }
                }
                .listRowBackground(Color.clear)
                .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                
                Section {
                    HStack {
                        Spacer()
                        VStack {
                            Image(systemName: "swift")
                                .font(.title)
                                .foregroundColor(.secondary)
                            
                            Text("WWDC 2025 Swift Student Challenge")
                                .foregroundColor(.secondary)
                                .font(.subheadline)
                                .padding()
                        }
                        Spacer()
                    }
                }
                .listRowBackground(Color.clear)
                .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
            }
            .scrollContentBackground(.hidden)
        }
        .padding()
    }
}

#Preview {
    SettingsApp()
}
