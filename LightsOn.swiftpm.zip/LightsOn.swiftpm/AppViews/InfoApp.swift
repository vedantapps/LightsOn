//
//  InfoApp.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/14/25.
//

import SwiftUI

struct InfoApp: View {
    var body: some View {
        VStack {
            HStack {
                Text("LightsOn")
                    .font(.title)
                    .fontWeight(.semibold)
                    .monospaced()
                
                Spacer()
                
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "x.circle.fill")
                        .foregroundStyle(.white)
                        .font(.title)
                }
            }
            Divider()
                .overlay(.white)
            
            ScrollView(showsIndicators: false) {
                Image("IconSmall")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 200 * 2/9, style: .continuous))
                    .padding()
                    .frame(maxWidth: .infinity)
                Group {
                    Text("An interactive story of teamwork and quick thinking")
                        .bold()
                        .padding()
                    Label("2025 Swift Student Challenge", systemImage: "swift")
                    
                    Text("Inspired by the Apple TV+ show Severance")
                }
                .font(.title2)
                
                Divider()
                    .padding(.vertical)
                
                // Messages
                AppInfoDetail(iconName: "message.fill", name: "Messages", description: "Send and receive messages from management.")
                
                // Power
                AppInfoDetail(iconName: "bolt.fill", name: "Power", description: "Manage power for the office, MDR terminals, and the break room.")
                
                // Refine
                AppInfoDetail(iconName: "numbers", name: "Refine", description: "Use hand tracking to hover near or tap on the active numbers to refine and clear them.")
                
                // Mapping
                AppInfoDetail(iconName: "map.fill", name: "Mapping", description: "Use your Apple Pencil or finger to draw maps and hallways.")
                
                // Countdown
                AppInfoDetail(iconName: "calendar", name: "Countdown", description: "Count down the days until June 2025.")
                
                Divider()
                    .overlay(.white)
                    .padding(.vertical)
                
                // General
                AppInfoDetail(iconName: "info", name: "About", description: "LightsOn is built using SwiftUI, Vision, and PencilKit.")
            }
        }
        .padding()
    }
}

#Preview {
    InfoApp()
}

struct AppInfoDetail: View {
    @State var iconName: String
    @State var name: String
    @State var description: String
    
    var body: some View {
        HStack {
            Image(systemName: iconName)
                .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                .font(.largeTitle)
                .padding()
                .frame(width: 60)
            
            Divider()
            
            VStack(alignment: .leading) {
                Text(name)
                    .font(.title2)
                    .fontWeight(.semibold)
                Text(description)
            }
            .padding()
            
            Spacer()
            
        }
    }
}
