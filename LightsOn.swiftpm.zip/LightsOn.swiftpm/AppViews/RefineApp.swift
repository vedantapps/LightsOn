//
//  RefineApp.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/14/25.
//

import SwiftUI

struct RefineApp: View {
    
    // Hand Tracking
    @Binding var overlayPoints: [CGPoint]
    @State private var activeNumHovering = false
    
    // Refine App Setup
    @State private var gridItems = Array(repeating: 0, count: 80).map { _ in Int.random(in: 0...9) }
    @State private var selectedNumber = Int.random(in: 0..<80)
    @State private var scaleEffect = 1.0
    @State private var shakeEffect = 0.0
    @State private var changeColor = Color(red: 0.39, green: 1.00, blue: 1.00)
    @State private var nonScaleEffect = 1.0
    
    @Binding var usedRefineBefore: Bool
    @State private var showRefineTutorial = false
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Text("Refine")
                        .font(.title)
                        .fontWeight(.semibold)
                        .monospaced()
                    
                    Spacer()
                    
                    Text("Use hand gestures to hover near or tap the active number to refine")
                        .padding(.trailing)
                        .multilineTextAlignment(.center)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    HStack {
                        Image(systemName: "hand.wave.fill")
                        Text("Tracking Active")
                    }
                    .font(.title)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
                    .overlay {
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .stroke(.secondary, lineWidth: 1)
                    }
                    .padding(.trailing)
                    
                    Button {
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close"), object: self, userInfo: nil)
                    } label: {
                        Image(systemName: "x.circle.fill")
                            .foregroundStyle(.white)
                            .font(.title)
                    }
                    
                }
                Divider()
                    .overlay(.white)
                
                Spacer()
                
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 1), count: 8), spacing: 6) {
                    ForEach(0..<gridItems.count, id: \.self) { item in
                        if item == selectedNumber {
                            Text("\(gridItems[item])")
                                .font(.title)
                                .foregroundStyle(changeColor)
                                .monospaced()
                                .bold()
                                .scaleEffect(scaleEffect)
                                .offset(x: shakeEffect, y: shakeEffect)
                                .onAppear {
                                    withAnimation(.linear(duration: 1.0).repeatForever()) {
                                        scaleEffect = 2
                                    }
                                    withAnimation(.linear(duration: 0.15).repeatForever(autoreverses: true)) {
                                        shakeEffect = 3
                                    }
                                    withAnimation(.linear(duration: 3.0)) {
                                        changeColor = .red
                                    }
                                }
                                .onTapGesture {
                                    gridItems[item] = Int.random(in: 0...9)
                                    selectedNumber = Int.random(in: 0..<80)
                                    scaleEffect = 1.0
                                    shakeEffect = 0.0
                                    changeColor = .white
                                }
                                .hoverOverlay(overlayPoints: overlayPoints, isHovering: $activeNumHovering, isActiveNumber: true, hoverAction: {
                                    gridItems[item] = Int.random(in: 0...9)
                                    selectedNumber = Int.random(in: 0..<80)
                                    scaleEffect = 1.0
                                    shakeEffect = 0.0
                                    changeColor = .white
                                })
                        } else {
                            DefaultNumberView(item: gridItems[item], scaleEffect: $nonScaleEffect, overlayPoints: $overlayPoints)
                            
                        }
                        
                    }
                }
                
                
                Spacer()
            }
            .padding()
            .overlay {
                VStack {
                    Text("Thumb")
                    Circle()
                        .frame(width: 10, height: 10)
                        .foregroundColor(.green)
                }
                .position(overlayPoints.first ?? CGPoint(x: -2000, y: -2000))
                
                VStack {
                    Text("Index")
                    Circle()
                        .frame(width: 10, height: 10)
                        .foregroundColor(.green)
                }
                .position(overlayPoints.count > 1 ? overlayPoints[1] : CGPoint(x: -2000, y: -2000))
                .sheet(isPresented: $showRefineTutorial) {
                    RefineTutorial()
                }
            }
            
        }
        .onAppear {
            if !usedRefineBefore {
                showRefineTutorial.toggle()
                usedRefineBefore = true
            }
        }
    }
}

#Preview {
    RefineApp(overlayPoints: .constant([CGPointZero]), usedRefineBefore: .constant(false))
}

struct DefaultNumberView: View {
    @State var item: Int
    @Binding var scaleEffect: Double
    @Binding var overlayPoints: [CGPoint]
    
    @State var isHovering = false
    
    var body: some View {
        Text("\(item)")
            .font(.title)
            .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
            .monospaced()
            .scaleEffect(isHovering ? 1.5 : 1.0)
            .shadow(radius: isHovering ? 5 : 0)
            .contentShape(Rectangle())
            .clipped()
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, isActiveNumber: false, hoverAction: {
            })
    }
}

let xRangeMin: Double = 180
let xRangeMax: Double = 400
let yRangeMin: Double = 80
let yRangeMax: Double = 200

extension View {
    func hoverOverlay(overlayPoints: [CGPoint], isHovering: Binding<Bool>, isActiveNumber: Bool, hoverAction: @escaping () -> Void) -> some View {
        self.overlay {
            GeometryReader { geometry in
                Color.clear
                    .onChange(of: overlayPoints) {
                        if let firstPoint = overlayPoints.first {
                            if overlayPoints.count > 1 {
                                let secondPoint = overlayPoints[1]
                                let buttonRect = geometry.frame(in: .global)
                                if ((firstPoint.x + xRangeMin...firstPoint.x + xRangeMax).contains(buttonRect.minX) && (firstPoint.y + yRangeMin...firstPoint.y + yRangeMax).contains(buttonRect.minY)) || ((secondPoint.x + xRangeMin...secondPoint.x + xRangeMax).contains(buttonRect.minX) && (secondPoint.y + yRangeMin...secondPoint.y + yRangeMax).contains(buttonRect.minY)){
                                    withAnimation {
                                        isHovering.wrappedValue = true
                                    }
                                    
                                    if isActiveNumber {
                                        hoverAction()
                                    }
                                } else {
                                    withAnimation {
                                        isHovering.wrappedValue = false
                                    }
                                }
                            }
                        } else {
                            withAnimation {
                                isHovering.wrappedValue = false
                            }
                        }
                    }
            }
        }
    }
}
