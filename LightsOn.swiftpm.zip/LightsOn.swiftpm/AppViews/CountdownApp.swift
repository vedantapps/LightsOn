//
//  CountdownApp.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/14/25.
//

import SwiftUI

struct CountdownApp: View {
    
    @State private var days = 0
    
    var body: some View {
        VStack {
            HStack {
                Text("Countdown")
                    .font(.title)
                    .fontWeight(.semibold)
                    .monospaced()
                Spacer()
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "x.circle.fill")
                        .foregroundStyle(.white)
                        .font(.title)
                }
            }
            
            Divider()
                .overlay(.white)
            
            Spacer()
            
            HStack {
                Image(systemName: "calendar")
                Image(systemName: "swift")
            }
            .font(.system(size: 100))

            Text("WWDC 2025")
                .font(.system(size: 80))
                .bold()

            Text("\(days)")
                .font(.system(size: 80))
                .bold()
            
            Text("days till June")
                .font(.system(size: 25))
            
            Spacer()
        }
        .padding()
        .onAppear {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            let dateFormatted = formatter.date(from: "2025-06-01")
            let currentDate = Date()
            let components = Set<Calendar.Component>([.day])
            let difference = Calendar.current.dateComponents(components, from: currentDate, to: dateFormatted!)
            days = difference.day!
        }
    }
}

#Preview {
    CountdownApp()
}
