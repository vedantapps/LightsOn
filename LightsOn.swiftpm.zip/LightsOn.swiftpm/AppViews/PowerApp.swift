//
//  PowerApp.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/14/25.
//

import SwiftUI

struct PowerApp: View {
    
    @Binding var hasCompletedStory: Bool
    @Binding var currentApp: String
    @Binding var finishStory: Bool
    @Binding var bgColor: Color
    
    @State private var buttonOneState = false
    @State private var buttonTwoState = false
    @State private var buttonThreeState = false
    
    var body: some View {
        VStack {
            HStack {
                Text("Power Manager")
                    .font(.title)
                    .fontWeight(.semibold)
                    .monospaced()
                Spacer()
                
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "x.circle.fill")
                        .foregroundStyle(.white)
                        .font(.title)
                }
                
            }
            Divider()
                .overlay(.white)
            
            Spacer()
            
            // Main Power
            HStack {
                Image(systemName: "bolt.square.fill")
                    .font(.largeTitle)
                    .frame(width: 60, alignment: .leading)
                    .padding(.leading, 5)
                
                Text("Main Power")
                    .font(.system(size: 40))
                    .bold()
                    .monospaced()
                
                Spacer()
                
                Button {
                    buttonOneState = true
                    if buttonOneState && buttonTwoState && buttonThreeState {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            hasCompletedStory = true
                            currentApp = "messages"
                            withAnimation {
                                bgColor = Color(red: 0.04, green: 0.15, blue: 0.18)
                            }
                        }
                    }
                } label: {
                    if buttonOneState {
                        Text("ON")
                            .font(.system(size: 40))
                            .bold(true)
                            .monospaced()
                            .frame(width: 95, height: 95)
                            .foregroundStyle(.black)
                            .background{
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(RadialGradient(gradient: Gradient(colors: [Color.green, Color.green.opacity(0.6)]), center: .center, startRadius: 5, endRadius: 30))
                                    .shadow(color: Color.white, radius: 10, x: 0, y: 2)
                            }
                    } else {
                        Text("OFF")
                            .font(.system(size: 40))
                            .bold(true)
                            .monospaced()
                            .frame(width: 95, height: 95)
                            .foregroundStyle(.black)
                            .background{
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(RadialGradient(gradient: Gradient(colors: [Color.gray, Color.gray.opacity(0.6)]), center: .center, startRadius: 5, endRadius: 30))
                                    .shadow(color: Color.white, radius: 10, x: 0, y: 2)
                            }
                    }
                }
                .buttonStyle(.plain)
                .allowsHitTesting(!hasCompletedStory)
                .padding(.trailing)
            }
            
            
            Divider()
                .padding(.vertical, 5)
            
            
            // MDR
            HStack {
                Image(systemName: "numbers.rectangle.fill")
                    .font(.largeTitle)
                    .frame(width: 65, alignment: .leading)
                
                Text("MDR Terminals")
                    .font(.system(size: 40))
                    .bold()
                    .monospaced()
                
                Spacer()
                
                Button {
                    buttonTwoState = true
                    if buttonOneState && buttonTwoState && buttonThreeState {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            hasCompletedStory = true
                            currentApp = "messages"
                            withAnimation {
                                bgColor = Color(red: 0.04, green: 0.15, blue: 0.18)
                            }
                        }
                    }
                } label: {
                    if buttonTwoState {
                        Text("ON")
                            .font(.system(size: 40))
                            .bold(true)
                            .monospaced()
                            .frame(width: 95, height: 95)
                            .foregroundStyle(.black)
                            .background{
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(RadialGradient(gradient: Gradient(colors: [Color.green, Color.green.opacity(0.6)]), center: .center, startRadius: 5, endRadius: 30))
                                    .shadow(color: Color.white, radius: 10, x: 0, y: 2)
                            }
                    } else {
                        Text("OFF")
                            .font(.system(size: 40))
                            .bold(true)
                            .monospaced()
                            .frame(width: 95, height: 95)
                            .foregroundStyle(.black)
                            .background{
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(RadialGradient(gradient: Gradient(colors: [Color.gray, Color.gray.opacity(0.6)]), center: .center, startRadius: 5, endRadius: 30))
                                    .shadow(color: Color.white, radius: 10, x: 0, y: 2)
                            }
                    }
                }
                .buttonStyle(.plain)
                .allowsHitTesting(!hasCompletedStory)
                .padding(.trailing)
                
            }
            
            Divider()
                .padding(.vertical, 5)
            
            
            // Break Room
            HStack {
                Image(systemName: "person.bubble")
                    .font(.largeTitle)
                    .frame(width: 65, alignment: .leading)
                
                Text("Break Room")
                    .font(.system(size: 40))
                    .bold()
                    .monospaced()
                
                Spacer()
                
                Button {
                    buttonThreeState = true
                    if buttonOneState && buttonTwoState && buttonThreeState {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            hasCompletedStory = true
                            currentApp = "messages"
                            withAnimation {
                                bgColor = Color(red: 0.04, green: 0.15, blue: 0.25)
                            }
                        }
                    }
                } label: {
                    if buttonThreeState {
                        Text("ON")
                            .font(.system(size: 40))
                            .bold(true)
                            .monospaced()
                            .frame(width: 95, height: 95)
                            .foregroundStyle(.black)
                            .background{
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(RadialGradient(gradient: Gradient(colors: [Color.green, Color.green.opacity(0.6)]), center: .center, startRadius: 5, endRadius: 30))
                                    .shadow(color: Color.white, radius: 10, x: 0, y: 2)
                            }
                    } else {
                        Text("OFF")
                            .font(.system(size: 40))
                            .bold(true)
                            .monospaced()
                            .frame(width: 95, height: 95)
                            .foregroundStyle(.black)
                            .background{
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(RadialGradient(gradient: Gradient(colors: [Color.gray, Color.gray.opacity(0.6)]), center: .center, startRadius: 5, endRadius: 30))
                                    .shadow(color: Color.white, radius: 10, x: 0, y: 2)
                            }
                    }
                }
                .buttonStyle(.plain)
                .allowsHitTesting(!hasCompletedStory)
                .padding(.trailing)
            }
            
            
            Spacer()
        }
        .padding()
        .onAppear {
            if hasCompletedStory {
                buttonOneState = true
                buttonTwoState = true
                buttonThreeState = true
            }
        }
    }
}

#Preview {
    PowerApp(hasCompletedStory: .constant(false), currentApp: .constant("power"), finishStory: .constant(true), bgColor: .constant(.black))
}
