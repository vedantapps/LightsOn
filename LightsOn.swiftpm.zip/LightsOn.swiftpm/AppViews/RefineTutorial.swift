//
//  RefineTutorial.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/21/25.
//

import SwiftUI

struct RefineTutorial: View {
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack {
            Text("For Best Results")
                .font(.largeTitle)
                .bold()
                .monospaced()
                .padding(.top)
            
            List {
                HStack {
                    Image("Refine1")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 230, height: 200, alignment: .center)
                        .clipShape(RoundedRectangle(cornerRadius: 5, style: .continuous))
                        .padding(2)
                    
                    Text("""
                         iPad is steady and in a well lit environment
                         
                         Ensure that only one hand is visible
                         
                         Ensure all fingers are visible
                         
                         Your hand is 2 feet - 2.5 feet (24 inches - 30 inches) away from the screen
                         
                         Tracking settings can be adjusted in the Settings app
                         """)
                        .padding()
                        .font(.headline)
                }
                
                HStack {
                    Image("Refine2")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 230, height: 200, alignment: .top)
                        .clipShape(RoundedRectangle(cornerRadius: 5, style: .continuous))
                        .padding(2)
                    
                    Text("""
                         With all fingers visible move your hand to the corresponding number to refine
                         
                         Numbers can also be tapped on screen to be refined
                         """)
                        .padding()
                        .font(.headline)
                }
            }
            
            Button {
                dismiss()
            } label: {
                HStack {
                    Text("Dismiss")
                        .foregroundStyle(Color(red: 0.39, green: 1.00, blue: 1.00))
                        .font(.title)
                        .monospaced()
                    
                }
                .frame(height: 55)
                .padding(.horizontal)
                .frame(maxWidth: 300)
                .background {
                    Rectangle()
                        .foregroundStyle(.white.opacity(0.1))
                }
            }
            .padding()
            
        }
    }
}

#Preview {
    RefineTutorial()
}
