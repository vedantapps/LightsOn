//
//  MessagesApp.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/14/25.
//

import SwiftUI

struct MessagesApp: View {
    
    @Binding var hasCompletedStory: Bool
    @Binding var currentApp: String
    @Binding var tappedOnIntroMessage: Bool
    @Binding var finishStory: Bool
    
    @State private var show2ndMessage = false
    @State private var show3rdMessage = false
    @State private var show4thMessage = false
    
    var body: some View {
        VStack {
            HStack {
                Text("Messages")
                    .font(.title)
                    .fontWeight(.semibold)
                    .monospaced()
                
                Spacer()
                
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "x.circle.fill")
                        .foregroundStyle(.white)
                        .font(.title)
                }
                
            }
            Divider()
                .overlay(.white)
                .padding(.bottom,2 )

            VStack {
                Text("\(personName), I need your help ASAP. There has been a power failure in the office. Please respond and fix this immediately.")
            }
            .padding()
            .border(Color.white, width: 1)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.leading, 2)
            
            if show2ndMessage {
                VStack {
                    Text("Open the Power App and ensure all power is turned back on.")
                }
                .padding()
                .border(Color.white, width: 1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 2)
                
                if !hasCompletedStory {
                    Button {
                        currentApp = "power"
                    } label: {
                        HStack {
                            Text("Power")
                            Image(systemName: "arrow.up.forward")
                        }
                        .padding()
                        .border(Color.white, width: 1)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.leading, 2)
                    }
                }
                
            }
            
            if show3rdMessage {
                VStack {
                    Text("All done! Power restored.")
                }
                .padding()
                .border(Color.white, width: 1)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.trailing, 2)
                .padding(.vertical)
            }
            
            if show4thMessage {
                VStack {
                    Text("Thank you \(personName). You've completed the story. Feel free to explore the other experiences in the app. Tap on the info icon for a description of all of them.")
                }
                .padding()
                .border(Color.white, width: 1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 2)
            }
            
            Spacer()
        }
        .padding()
        .onAppear {
            tappedOnIntroMessage = true
            if hasCompletedStory {
                show2ndMessage = true
            }
            
            if !hasCompletedStory {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    withAnimation {
                        show2ndMessage = true
                    }
                }
            }
            
            if !finishStory && hasCompletedStory {
                show3rdMessage = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    withAnimation {
                        show4thMessage = true
                        finishStory = true
                    }
                }
            }
            
            if finishStory && hasCompletedStory {
                show3rdMessage = true
                show4thMessage = true
            }
            
        }
    }
}

#Preview {
    MessagesApp(hasCompletedStory: .constant(false), currentApp: .constant("messages"), tappedOnIntroMessage: .constant(false), finishStory: .constant(false))
}
