//
//  CameraView.swift
//  LightsOn
//
//  Created by Vedant Malhotra on 2/19/25.
//

import Foundation
import SwiftUI

struct CameraView: UIViewControllerRepresentable {
    var pointsProcessorHandler: (([CGPoint]) -> Void)?

    func makeUIViewController(context: Context) -> CameraViewController {
        let cameraView = CameraViewController()
        cameraView.pointsProcessorHandler = pointsProcessorHandler
        return cameraView
    }
    func updateUIViewController( _ uiViewController: CameraViewController,  context: Context) {
    }
}
